#include<bits/stdc++.h>
using namespace std;

//t=10101
int main()
{
	string t;
	
	cout<<"Enter Input Pattern:";
	cin>>t;
	string s = t;
	cout<<s<<endl;
	do
	{
		int A[5];
		for(int i=0;i<5;i++)
		{
			A[i] = (s[i]-'0');
		}
		
		s[0] = '0'+A[4];
		s[1] = '0'+(A[0] ^ A[3]);
		s[2] = '0'+(A[1] ^ A[2]);
		s[3] = '0'+A[2];
		s[4] = '0'+A[3];
		
		cout<<s<<endl;
	}while(s!=t);
	
	
}
