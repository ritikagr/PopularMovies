#include<iostream>
using namespace std;

char _xor(char a,char b)
{
	int i = a-'0',j = b-'0';
	int k = i^j;
	char l = k+'0';
	return l;
}

int main()
{
	// Implementing LFSR
	int n,i;
	cout<<"Enter no. of states in LFSR\n";
	cin>>n;
	cout<<"Enter coefficients of the polynomial\n";
	int h[n+1];
	h[0] = 1;
	h[n] = 1;
	for(i = 1;i<n;i++)
	{
		cin>>h[i];
	}
	
	string s,t;
	char temp;
	cout<<"Enter seed input of length "<<n<<"\n";
	cin>>s;
	t = s;
	do{
		temp = s[n-1];
		for(i = n-1;i>0;i--)
		{
			s[i] = s[i-1];
			if(h[i] == 1)
			{
				temp = _xor(temp,s[i-1]);
			}
			else if(h[i] == -1)
			{
				s[i] = _xor(temp,s[i-1]);
			}
		}
		s[0] = temp;
		cout<<s<<"\n";
	}while(s != t);
}
