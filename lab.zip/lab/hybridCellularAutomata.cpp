#include<bits/stdc++.h>
using namespace std;

int btod(char s[3])
{
	char *pend;
	return strtoull(s,&pend,2);
}

int main()
{
	bitset<8> b[4];
	int i;
	b[0] = bitset<8>(22);
	b[1] = bitset<8>(90);
	b[2] = bitset<8>(165);
	b[3] = bitset<8>(233);
	string s;
	char temp[3];
	cin>>s;
	bitset<4> prev;
	bitset<4> ip(s),op;
	int cnt = 0;
	prev = ip;
	set<int> st;
	
	do{
		st.insert(prev.to_ulong());
		op[3] = prev[3]^prev[0];
		op[3] = op[3]^prev[2];
		op[2] = prev[3]^prev[1];
		op[1] = prev[0]^prev[2];
		op[1] = ~op[1];
		op[0] = prev[0]^prev[1];
		op[0] = op[0]^prev[3];
		op[0] = ~op[0];
		cout<<"Cellular automata output --> "<<op<<"\n";
		cnt++;
		prev = op;
	}while(st.find(prev.to_ulong()) == st.end());
	
	prev = ip;
	st.clear();
	do{
		st.insert(prev.to_ulong());
		op[3] = prev[3]^0;
		op[3] = op[3]^prev[2];
		op[2] = prev[3]^prev[1];
		op[1] = prev[0]^prev[2];
		op[1] = ~op[1];
		op[0] = prev[0]^prev[1];
		op[0] = ~op[0];
		cout<<"Null boundary automata output --> "<<op<<"\n";
		cnt++;
		prev = op;
	}while(st.find(prev.to_ulong()) == st.end());
}
