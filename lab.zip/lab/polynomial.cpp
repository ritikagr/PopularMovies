#include<bits/stdc++.h>
using namespace std;

//p=1+x+x3 => 101
//t=110

int main()
{
string p,t;

cin>>p>>t;
string s = t;
cout<<endl;

int a = pow(2,t.size())-1;
int cnt = 0;
do{
cnt++;
cout<<s<<endl;
int n = s.length();
string x = s;
int r = s[n-1]-'0';
x[n-1] = x[n-2];

for(int i=n-2;i>=0;i--)
{
	int l = s[i]-'0';
	if(p[i]=='1')
	{
		r = l^r;
	}
	if(i>0)
	x[i] = x[i-1];
}

x[0] = '0'+r;
s = x;
}while(s!=t);

if(cnt==a)
cout<<"Primitive Polynomial"<<endl;
else
cout<<"Not Primitive Polynomial"<<endl;

}
