#include<bits/stdc++.h>
using namespace std;

char _xor(char a,char b)
{
	if(a==b)
	return '0';
	else
	return '1';
}

int main()
{
	cout<<"Input Pattern: ";
	string t;
	cin>>t;
	
	string s = t;
	string z = s;
	do{
		cout<<z<<endl;
		s = z;
		for(int i=0;i<4;i++)
		{
			z[i] = _xor(s[(i-1+4)%4], s[(i+1)%4]);
		}
	}
	while(z!=t && s!=z);
}
